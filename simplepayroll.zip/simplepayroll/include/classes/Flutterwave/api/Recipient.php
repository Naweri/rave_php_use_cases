<?php

namespace Recipient;

define("BASEPATH", 4);

include('rave.php');
include('raveEventHandlerInterface.php');

use Flutterwave\Rave;
use Flutterwave\Rave\EventHandlerInterface;



?>