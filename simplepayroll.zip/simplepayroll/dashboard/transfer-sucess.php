<h2>Transfer Success</h2>

<b>NB:</b> This does not mean that your transfer was successful. <br>You have to use the <code>batch_id</code> recieved from your call to get successful and failed transfers, together with other details.

<p><a href='index.php'>GoTo Home</a></p>